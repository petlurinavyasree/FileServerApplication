package multithreadfileserver;

public class Constants {

	public static int SERVER_PORT = 9090;
	//public static String IP = "0.0.0.0";//Uncomment & comment next line to test on local machine
	public static String IP = "ec2-52-90-199-246.compute-1.amazonaws.com";
	public static int MAX_POOL_SIZE = 5;
}
